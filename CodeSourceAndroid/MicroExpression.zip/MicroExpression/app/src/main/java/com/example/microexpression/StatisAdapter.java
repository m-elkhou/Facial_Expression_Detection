package com.example.microexpression;

import android.content.Context;
import android.media.audiofx.AudioEffect;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;
import java.util.List;

public class StatisAdapter extends RecyclerView.Adapter<StatisHolder> {
    // a gerer ce classe n'est pas bien rectifier
    Context context;
    List<EltDatabaseStat> ens;
    String date;

    public StatisAdapter(Context context, List<EltDatabaseStat> ens, String date) {
        this.context = context;
        this.ens = ens;
        this.date = date;
    }

    @NonNull
    @Override
    public StatisHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_recycler,parent,false);
        return new StatisHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StatisHolder holder, int position) {
        if(ens.isEmpty()) {
            Toast.makeText(context,"Statistics is empty!",Toast.LENGTH_LONG).show();
            holder.date_stat.setText("");
        }else{

            //holder.date_stat.setText(ens.get(position).getDate()); //ens.get(position).getDate()
            holder.date_stat.setText(date);
            List<PieEntry> pieEntries = new ArrayList<>();
            float[] rates = {10,10,20,37,15,6,2};
            String[] exps = {"Happy","Sad","Neural","Disgust","Anger","Fear","Surprise"};
            for(int i = 0; i<7;i++){
                //pieEntries.add(new PieEntry(rates[i],exps[i]));
                pieEntries.add(new PieEntry(Float.parseFloat(ens.get(i).getDate()),ens.get(i).getEmotion()));
            }
            holder.pieChart.animateXY(5000,5000);
            PieDataSet pieDataSet = new PieDataSet(pieEntries,"Statistics");
            pieDataSet.setColors(ColorTemplate.COLORFUL_COLORS);
            PieData pieData = new PieData(pieDataSet);
            holder.pieChart.setData(pieData);
            Description description = new Description();
            description.setText("this statistics reflet your daily use of our App.");
            holder.pieChart.setDescription(description);
            holder.pieChart.invalidate();

        }




    }

    @Override
    public int getItemCount() {
        return 1;
        //return ens.size();
    }
}
