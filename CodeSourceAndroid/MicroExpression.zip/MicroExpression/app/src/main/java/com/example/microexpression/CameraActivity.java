package com.example.microexpression;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.Camera;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.List;

public class CameraActivity extends AppCompatActivity {
    private FrameLayout frame_camera;
    private ImageView btn_back, btn_cam, btn_gallery, btn_flash,btn_camera_bf, btn_phone_cam;
    Camera camera;
    ShowCamera showCamera;
    Camera.PictureCallback mPictureCallback;
    private Boolean test_flash = false, test_camera = true;
    public static final int CAMERA_REQUEST = 9999, GALLERY_REQUEST = 9876;
    private Bitmap bitmap = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_camera);
        frame_camera = (FrameLayout) findViewById(R.id.frame_camera);
        btn_back = (ImageView)findViewById(R.id.btn_back);
        btn_cam = (ImageView)findViewById(R.id.btn_cam);
        btn_gallery = (ImageView)findViewById(R.id.btn_gallery);
        btn_flash =(ImageView)findViewById(R.id.btn_flash);
        btn_camera_bf = (ImageView)findViewById(R.id.btn_camera_bf);
        btn_phone_cam = (ImageView)findViewById(R.id.btn_phone_cam);
        btn_camera_bf.setVisibility(View.GONE);
        btn_flash.setVisibility(View.GONE);

        camera = Camera.open(Camera.CameraInfo.CAMERA_FACING_FRONT);
        showCamera = new ShowCamera(this, camera);
        frame_camera.addView(showCamera);


        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        mPictureCallback=new Camera.PictureCallback() {
            @Override
            public void onPictureTaken(byte[] data, Camera camera) {
                File picture_file = getOutPutMediaFile();
                if(picture_file == null){
                    return;
                }else{
                    try{
                        FileOutputStream fos = new FileOutputStream(picture_file);
                        fos.write(data);
                        fos.close();
                        bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
                        Toast.makeText(getApplicationContext(),"Image Saved in your internal sortage.",Toast.LENGTH_LONG).show();

                        BitmapHelper.getInstance().setBitmap(bitmap);
                        if(BitmapHelper.getInstance().getBitmap() == null){
                            Toast.makeText(getApplicationContext(),"No image captured!",Toast.LENGTH_LONG).show();
                        }else{
                            Intent in1 = new Intent(CameraActivity.this, SendImageServer.class);
                            startActivity(in1);

                        }

                        camera.startPreview();
                    }catch (IOException e){
                        e.printStackTrace();
                    }

                }

            }
        };

        btn_cam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(camera!=null){
                    camera.takePicture(null,null,mPictureCallback);
                    /*Intent in1 = new Intent(CameraActivity.this, SendImageServer.class);
                    //Convert to byte array
                    if(bitmap!=null){
                        ByteArrayOutputStream stream = new ByteArrayOutputStream();
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);
                        byte[] byteArray = stream.toByteArray();
                        in1.putExtra("image",byteArray);
                    }
                    startActivity(in1);*/

                }

            }
        });
        btn_flash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(camera!=null){
                    if(test_flash == false){
                        /*Camera.Parameters params = camera.getParameters();
                        //params.setFlashMode(Camera.Parameters.FLASH_MODE_ON);
                        List<String> flashModes = params.getSupportedFlashModes();
                        if (flashModes.contains(Camera.Parameters.FLASH_MODE_ON)) {
                            params.setFlashMode(Camera.Parameters.FLASH_MODE_ON);
                        }
                        camera.setParameters(params);*/
                        btn_flash.setImageResource(R.drawable.ic_flash_on);
                        turnLightOnn();
                        test_flash = true;
                    }else{
                        /*Camera.Parameters params = camera.getParameters();
                        //params.setFlashMode(Camera.Parameters.FLASH_MODE_ON);
                        List<String> flashModes = params.getSupportedFlashModes();
                        if (flashModes.contains(Camera.Parameters.FLASH_MODE_OFF)) {
                            params.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
                        }
                        camera.setParameters(params);*/
                        btn_flash.setImageResource(R.drawable.ic_flash_off);
                        turnLightOff();
                        test_flash = false;

                    }

                }

            }
        });

        btn_camera_bf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(test_camera == true){
                    //cameraBack();
                    test_camera = false;
                }else{
                    //cameraFront();
                    test_camera = true;
                }
            }
        });
        btn_gallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(
                        Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(i, GALLERY_REQUEST);

            }
        });
        btn_phone_cam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // le declenchement de camera
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent, CAMERA_REQUEST);
            }
        });

    }
    File getOutPutMediaFile(){
        String state = Environment.getExternalStorageState();
        if (!state.equals(Environment.MEDIA_MOUNTED)){
            return null;
        }else{
            File folder_gui =new File(Environment.getExternalStorageDirectory()+File.separator+"MOODCheck");
            if(!folder_gui.exists()){
                folder_gui.mkdir();
            }
            String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Timestamp(System.currentTimeMillis()));
            File outputfile = new File(folder_gui,timeStamp+".jpg");
            return outputfile;
        }
    }
    public void turnLightOff() {
        if (camera == null) {
            return;
        }
        Camera.Parameters parameters = camera.getParameters();
        if (parameters == null) {
            return;
        }
        List<String> flashModes = parameters.getSupportedFlashModes();
        String flashMode = parameters.getFlashMode();
        // Check if camera flash exists
        if (flashModes == null) {
            return;
        }
        if (!Camera.Parameters.FLASH_MODE_OFF.equals(flashMode)) {
            // Turn off the flash
            if (flashModes.contains(Camera.Parameters.FLASH_MODE_OFF)) {
                parameters.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
                camera.setParameters(parameters);
            } else {
               Toast.makeText(getApplicationContext(),"FLASH MODE OFF not supported",Toast.LENGTH_LONG).show();
            }
        }
    }

    public void turnLightOnn() {
        if (camera == null) {
            return;
        }
        Camera.Parameters parameters = camera.getParameters();
        if (parameters == null) {
            return;
        }
        List<String> flashModes = parameters.getSupportedFlashModes();
        String flashMode = parameters.getFlashMode();
        // Check if camera flash exists
        if (flashModes == null) {
            return;
        }
        if (!Camera.Parameters.FLASH_MODE_ON.equals(flashMode)) {
            // Turn off the flash
            if (flashModes.contains(Camera.Parameters.FLASH_MODE_ON)) {
                parameters.setFlashMode(Camera.Parameters.FLASH_MODE_ON);
                camera.setParameters(parameters);
            } else {
                Toast.makeText(getApplicationContext(),"FLASH MODE ON not supported",Toast.LENGTH_LONG).show();
            }
        }
    }
    public void cameraFront(){
        if (camera == null) {
            return;
        }
        Camera.Parameters parameters = camera.getParameters();
        if (parameters == null) {
            return;
        }
        parameters.set("camera-id", 2);
        parameters.setPreviewSize(640, 480);
        camera.setParameters(parameters);
    }
    public void cameraBack(){
        if (camera == null) {
            return;
        }
        Camera.Parameters parameters = camera.getParameters();
        if (parameters == null) {
            return;
        }
        parameters.set("camera-id", 1);
        parameters.setPreviewSize(640, 480);
        camera.setParameters(parameters);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == CAMERA_REQUEST && resultCode == RESULT_OK && null != data){
            bitmap=(Bitmap) data.getExtras().get("data");
            //send image
            /*Intent in1 = new Intent(CameraActivity.this, SendImageServer.class);
            if(bitmap!=null){
                //Convert to byte array
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                //bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);
                byte[] byteArray = stream.toByteArray();
                in1.putExtra("image",byteArray);
            }
            startActivity(in1);*/
            BitmapHelper.getInstance().setBitmap(bitmap);
            if(BitmapHelper.getInstance().getBitmap() == null){
                Toast.makeText(getApplicationContext(),"No image captured!",Toast.LENGTH_LONG).show();
            }else{
                Intent in1 = new Intent(CameraActivity.this, SendImageServer.class);
                startActivity(in1);

            }

        }else if(requestCode == GALLERY_REQUEST && resultCode == RESULT_OK && null != data){
            Uri selectedImage = data.getData();
            String[] filePathColumn = { MediaStore.Images.Media.DATA };

            Cursor cursor = getContentResolver().query(selectedImage,filePathColumn, null, null, null);
            cursor.moveToFirst();

            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);
            cursor.close();

            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bitmap = BitmapFactory.decodeFile(picturePath,bmOptions);
            BitmapHelper.getInstance().setBitmap(bitmap);
            if(BitmapHelper.getInstance().getBitmap() == null){
                Toast.makeText(getApplicationContext(),"No image selected!",Toast.LENGTH_LONG).show();
            }else{
                Intent in1 = new Intent(CameraActivity.this, SendImageServer.class);
                startActivity(in1);

            }
            /*
            //send image
            Intent in1 = new Intent(CameraActivity.this, SendImageServer.class);
            //Convert to byte array
            if(bitmap!=null){
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                //bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);
                byte[] byteArray = stream.toByteArray();
                in1.putExtra("image",byteArray);
            }
            startActivity(in1);*/

        }
    }

}
