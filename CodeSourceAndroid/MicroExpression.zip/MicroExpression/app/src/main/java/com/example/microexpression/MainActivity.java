package com.example.microexpression;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.AnimationDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.format.Formatter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.Calendar;
import java.util.prefs.Preferences;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity extends AppCompatActivity {
    private TextView id_txt_configureServer;
    private LinearLayout layout_anim, lyn_debut, lyn_photo;
    private  AnimationDrawable animationDrawable;
    private ImageView btn_info, btn_statis;
    private CircleImageView img_photo;
    private Button btn_start_now, btn_send;
    public static final int CAMERA_REQUEST = 9999;
    private Bitmap bitmap;
    private EditText tx_port, tx_ip;
    private String sp_ip, sp_port;
    public static final int PERMISSIONS_REQUEST_CAM = 23, PERMISSIONS_REQUEST_WRITE = 34;
    public static final int PERMISSION_ALL = 1;
    String[] PERMISSIONS = {
            android.Manifest.permission.CAMERA,
            Manifest.permission.INTERNET,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };
    WifiManager wifiManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
         wifiManager= (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);

        sp_port = Pref.getPrefs("port", getApplicationContext());;
        sp_ip = Pref.getPrefs("IP", getApplicationContext());



        //Notification

        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.SECOND,5);

        Intent notif = new Intent(getApplicationContext(), NotificationReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(getApplicationContext(), 100, notif, PendingIntent.FLAG_UPDATE_CURRENT);
        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        alarmManager.setRepeating(AlarmManager.RTC_WAKEUP,calendar.getTimeInMillis(),AlarmManager.INTERVAL_HALF_HOUR,pendingIntent);

        // recuperation des composants GUI
        lyn_debut = (LinearLayout)findViewById(R.id.lyn_debut);
        lyn_photo = (LinearLayout)findViewById(R.id.lyn_photo);
        img_photo = (CircleImageView) findViewById(R.id.img_photo);
        btn_send = (Button) findViewById(R.id.btn_envoyer);


        // Animation
        layout_anim = (LinearLayout) findViewById(R.id.layout_anim);
        animationDrawable = (AnimationDrawable)layout_anim.getBackground();
        animationDrawable.setEnterFadeDuration(2000);
        animationDrawable.setExitFadeDuration(4000);
        animationDrawable.start();
        // Button info
        btn_info = (ImageView)findViewById(R.id.btn_info);
        btn_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Apropos.class);
                startActivity(intent);

            }
        });
        // Button statistique
        btn_statis = (ImageView)findViewById(R.id.btn_statis);
        btn_statis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Statistiques.class);
                startActivity(intent);

            }
        });


        id_txt_configureServer = (TextView) findViewById(R.id.id_txt_configureServer);
        id_txt_configureServer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCustomDialog();
            }
        });

        // Button Camera il declenche le camera
        btn_start_now = (Button) findViewById(R.id.btn_start_now);
        btn_start_now.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // le declenchement de camera
                /*Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent, CAMERA_REQUEST);
                */
                //Intent intent = new Intent(getApplicationContext(), CameraActivity.class);
                //startActivity(intent);

                //**********************************************************************************************
                if (!hasPermissions(MainActivity.this, PERMISSIONS)) {
                    ActivityCompat.requestPermissions(MainActivity.this, PERMISSIONS, PERMISSION_ALL);
                }else{
                    // permission is granted
                   if(isConnected()){
                       if(sp_ip != null &&  sp_port != null){
                           Intent intent = new Intent(getApplicationContext(), SendImageServer.class);
                           startActivity(intent);
                       }else{
                           Toast.makeText(getApplicationContext(),"You should configure the server!",Toast.LENGTH_LONG).show();
                       }

                   }else{
                       Toast.makeText(getApplicationContext(),"You should be connected to the internet!",Toast.LENGTH_LONG).show();
                   }

                }
                //**********************************************************************************************


                // Here, thisActivity is the current activity
                /*
                if (ContextCompat.checkSelfPermission(MainActivity.this,
                        Manifest.permission.CAMERA )
                        != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(MainActivity.this,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE )
                        != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(MainActivity.this,
                            new String[]{Manifest.permission.CAMERA},
                            PERMISSIONS_REQUEST_CAM);
                    ActivityCompat.requestPermissions(MainActivity.this,
                            new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                            PERMISSIONS_REQUEST_WRITE);
                    // Permission is not granted
                    // Should we show an explanation?
                    if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this,
                            Manifest.permission.CAMERA) && ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                        // Show an explanation to the user *asynchronously* -- don't block
                        // this thread waiting for the user's response! After the user
                        // sees the explanation, try again to request the permission.
                    } else {
                        // No explanation needed; request the permission
                        ActivityCompat.requestPermissions(MainActivity.this,
                                new String[]{Manifest.permission.CAMERA},
                                PERMISSIONS_REQUEST_CAM);
                        ActivityCompat.requestPermissions(MainActivity.this,
                                new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                                PERMISSIONS_REQUEST_WRITE);

                        // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                        // app-defined int constant. The callback method gets the
                        // result of the request.
                    }
                } else {
                    Intent intent = new Intent(getApplicationContext(), CameraActivity.class);
                    startActivity(intent);
                }*/
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == CAMERA_REQUEST){
            bitmap=(Bitmap) data.getExtras().get("data");
            img_photo.setImageBitmap(bitmap);
            lyn_debut.setVisibility(View.GONE);
            lyn_photo.setVisibility(View.VISIBLE);



        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_ALL: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    //Intent intent = new Intent(getApplicationContext(), SendImageServer.class);
                    //startActivity(intent);
                    // permission is granted
                    if(isConnected()){
                        if(sp_ip != null &&  sp_port != null){
                            Intent intent = new Intent(getApplicationContext(), SendImageServer.class);
                            startActivity(intent);
                        }else{
                            Toast.makeText(getApplicationContext(),"You should configure the server!",Toast.LENGTH_LONG).show();
                        }

                    }else{
                        Toast.makeText(getApplicationContext(),"You should be connected to the internet!",Toast.LENGTH_LONG).show();
                    }
                } else {
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return;
            }
            // other 'case' lines to check for other
            // permissions this app might request.
        }
    }
    public static boolean hasPermissions(Context context, String... permissions) {
        if (context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }

    public boolean isConnected() {
        boolean connected = false;
        try {
            ConnectivityManager cm = (ConnectivityManager)getApplicationContext().getSystemService(getApplicationContext().CONNECTIVITY_SERVICE);
            NetworkInfo nInfo = cm.getActiveNetworkInfo();
            connected = nInfo != null && nInfo.isAvailable() && nInfo.isConnected();
            return connected;
        } catch (Exception e) {
            Log.e("Connectivity Exception", e.getMessage());
        }
        return connected;
    }
    private void showCustomDialog() {
        ViewGroup viewGroup = findViewById(android.R.id.content);
        View dialogView = LayoutInflater.from(this).inflate(R.layout.server_dialog, viewGroup, false);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(dialogView);
        final AlertDialog alertDialog = builder.create();



        tx_ip = (EditText)dialogView.findViewById(R.id.dia_ip_address);
        tx_port = (EditText) dialogView.findViewById(R.id.dia_port_number);




        //String ipAddress = Formatter.formatIpAddress(wifiManager.getConnectionInfo().getIpAddress());
        //tx_ip.setText(ipAddress);
        tx_port.setText("5000");


        TextView tv_curr_ip = (TextView) dialogView.findViewById(R.id.tv_curr_ip);
        TextView tv_curr_port = (TextView)dialogView.findViewById(R.id.tv_curr_port);


        LinearLayout lyn_edit = (LinearLayout) dialogView.findViewById(R.id.dia_modify);
        LinearLayout lyn_configure =(LinearLayout) dialogView.findViewById(R.id.dia_configure);

        LinearLayout lyn_current =  (LinearLayout)dialogView.findViewById(R.id.lyn_current);


        if ( sp_ip != null &&  sp_port != null )
        {
            //if isn't empty'
            tv_curr_ip.setText("Current IP: "+Pref.getPrefs("IP", getApplicationContext()));
            tv_curr_port.setText("Port: "+Pref.getPrefs("port",getApplicationContext()));
            lyn_current.setVisibility(View.VISIBLE);
        }else{
            //else set visiblity gone
            lyn_current.setVisibility(View.GONE);
        }




        lyn_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // modify ip and port in dataBase

                Toast.makeText(getApplicationContext(),"The Server IP and Port were edited", Toast.LENGTH_LONG).show();
                alertDialog.hide();
            }
        });
        lyn_configure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Configure ip and port in dataBase
                boolean portv = portValide(tx_port);
                boolean ipv = ipValide(tx_ip);

                if (portv==true && ipv == true ) {
                    // test on shared preference
                    String port = tx_port.getText().toString().trim();
                    String ip = tx_ip.getText().toString().trim();
                    Pref.setPrefs("port",port,"IP",ip, getApplicationContext());
                    Toast.makeText(getApplicationContext(), "The Server was Configured", Toast.LENGTH_LONG).show();
                    alertDialog.hide();

                }

            }
        });

        alertDialog.show();
    }
    private boolean validate_port(String port){
        try{
            int i = Integer.parseInt(port);
            return true;
        }catch (NumberFormatException e){
            return false;
        }
    }
    private boolean portValide(EditText tx_port){
        String port = tx_port.getText().toString().trim();
        if(port.isEmpty()){
            tx_port.setError("Port Empty!");
            return false;
        }else if(validate_port(port)==false){
            tx_port.setError("Port Invalid!");
            return false;
        }else{
            tx_port.setError(null);
            return true;
        }
    }
    private boolean ipValide(EditText tx_ip){
        String ip = tx_ip.getText().toString().trim();
        IPAddressValidator ipAddressValidator = new IPAddressValidator();
        boolean valid_ip = ipAddressValidator.validate(ip);
        if(ip.isEmpty()){
            tx_ip.setError("IP Empty!");
            return false;
        }else if(valid_ip == false){
            tx_ip.setError("IP Invalid!");
            return false;

        }else{
            tx_ip.setError(null);
            return true;
        }
    }




}
