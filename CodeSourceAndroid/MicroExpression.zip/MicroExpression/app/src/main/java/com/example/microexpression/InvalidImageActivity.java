package com.example.microexpression;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;

public class InvalidImageActivity extends AppCompatActivity {
    private LinearLayout lyn_photo;
    private AnimationDrawable animationDrawable;
    private Button btn_error_retry;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_invalid_image);

        //******************************************************************************************
        // Animation
        lyn_photo = (LinearLayout) findViewById(R.id.lyn_photo);
        animationDrawable = (AnimationDrawable)lyn_photo.getBackground();
        animationDrawable.setEnterFadeDuration(2000);
        animationDrawable.setExitFadeDuration(4000);
        animationDrawable.start();

        //******************************************************************************************
        btn_error_retry = (Button)findViewById(R.id.btn_error_retry);
        btn_error_retry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), SendImageServer.class);
                startActivity(intent);


            }
        });


    }
}
