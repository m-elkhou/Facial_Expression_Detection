package com.example.microexpression;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.github.mikephil.charting.charts.PieChart;

public class StatisHolder extends RecyclerView.ViewHolder {
    TextView date_stat;
    PieChart pieChart;

    public StatisHolder(@NonNull View itemView) {
        super(itemView);
        this.date_stat = itemView.findViewById(R.id.date_stat);
        this.pieChart = itemView.findViewById(R.id.piechart);
    }
}
