package com.example.microexpression;

/**
 * ce classe permet mettre la configuration de serveur interne à l'app
 */

public class UploadServer {
    private static final String ROOT_URL = "http:/"+"IP:numéro port"+"/";
    public static final String UPLOAD_URL = ROOT_URL + "api/image";

}
