package com.example.microexpression;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;

public class ImageAnalyzed implements Serializable {
    private String url;
    private String emotions;
    private String pourcent;

    ImageAnalyzed(){

    }

    public ImageAnalyzed(String url) {
        this.url = url;
    }

    public ImageAnalyzed(String url, String emotions, String pourcent) {
        this.url = url;
        this.emotions = emotions;
        this.pourcent = pourcent;
    }
    // getters && setters


    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getEmotions() {
        return emotions;
    }

    public void setEmotions(String emotions) {
        this.emotions = emotions;
    }

    public String getPourcent() {
        return pourcent;
    }

    public void setPourcent(String pourcent) {
        this.pourcent = pourcent;
    }

    // list of emotions
    public String[] listeEmotions(){
        String[] parts = this.emotions.split(",");
        //ArrayList<String> list_emotions = (ArrayList) Arrays.asList(parts);
        return parts;
    }
    // list of pourcentages
    public String[] listePourcent(){
        String[] parts = this.pourcent.split(",");
        //ArrayList<String> list_pourcent = (ArrayList) Arrays.asList(parts);
        return parts;
    }
}
