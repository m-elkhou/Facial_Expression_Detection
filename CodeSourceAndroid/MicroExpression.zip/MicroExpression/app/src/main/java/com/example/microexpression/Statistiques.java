package com.example.microexpression;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Canvas;
import android.media.Image;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Statistiques extends AppCompatActivity {
    private ImageView btn_stat_back, id_btn_delete;
    private RecyclerView recyclerView;
    private StatisAdapter adapter;
    private ArrayList<EltDatabaseStat> ens;
    private RelativeLayout layout;
    private ToggleButton toggle;
    private DatabaseHelper db;
    private String d=""; // date de début et fin de statistique
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_statistiques);

        toggle = (ToggleButton) findViewById(R.id.toggle1);
        toggle.setVisibility(View.GONE);

        toggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    // The toggle is enabled textOn="WEEK"
                    // afficher des statistiques pour chaque semaine
                } else {
                    // The toggle is disabled textOff="MONTH"
                    // afficher des statistiques pour chaques month
                }
            }
        });
        // retourner à l'activité principale
        btn_stat_back = (ImageView)findViewById(R.id.btn_stat_back);
        btn_stat_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Statistiques.this, MainActivity.class);
                startActivity(i);
                finish();
            }
        });
        ens = new ArrayList<>();
        //ens.add(new EltDatabaseStat("happy","12/05/03"));
        db = new DatabaseHelper(this);
        Cursor cursor = db.getAllData();
        while(cursor.moveToNext()){
            EltDatabaseStat e = new EltDatabaseStat(cursor.getString(1),cursor.getString(3));
            ens.add(e);
        }

        // c'est juste pour le teste est ce que les statistiques fonctionne bien
        /*ens.add(new EltDatabaseStat("fear","2017-01-01 02:05:00"));
        ens.add(new EltDatabaseStat("happy","2017-01-01 02:15:00"));
        ens.add(new EltDatabaseStat("happy","2017-01-01 02:25:00"));
        ens.add(new EltDatabaseStat("fear","2017-01-01 02:30:00"));
        ens.add(new EltDatabaseStat("anger","2017-01-01 02:35:00"));
        ens.add(new EltDatabaseStat("anger","2017-01-01 02:39:00"));
        ens.add(new EltDatabaseStat("surprise","2017-02-02 03:35:00"));
        ens.add(new EltDatabaseStat("neural","2017-02-02 04:35:00"));
        ens.add(new EltDatabaseStat("neural","2019-01-01 04:35:00"));*/
        if(!ens.isEmpty()){
            d = ens.get(0).getDate().substring(0,10)+" à "+ens.get(ens.size()-1).getDate().substring(0,10);
            HashMap<String,Float>  hash = new HashMap<>();
            hash.putAll(AllStat(ens));
            ens.clear();
            Iterator<Map.Entry<String, Float>> it = hash.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<String, Float> pair = (Map.Entry)it.next();
                ens.add(new EltDatabaseStat((String)pair.getKey(), pair.getValue()+""));
                it.remove();
            }

        }

        recyclerView = (RecyclerView)findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new StatisAdapter(this,ens, d);
        recyclerView.setAdapter(adapter);


        id_btn_delete = (ImageView) findViewById(R.id.id_btn_delete);
        id_btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCustomDialog();
            }
        });

        recyclerView.addItemDecoration(new DividerItemDecoration(getApplicationContext(), LinearLayoutManager.VERTICAL) {
            @Override
            public void onDraw(Canvas c, RecyclerView parent, RecyclerView.State state) {
                // Do not draw the divider
            }
        });


    }

    private void showCustomDialog() {
        ViewGroup viewGroup = findViewById(android.R.id.content);
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialogue_delete, viewGroup, false);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(dialogView);
        final AlertDialog alertDialog = builder.create();



        TextView del_no = (TextView) dialogView.findViewById(R.id.del_no);
        TextView del_yes = (TextView)dialogView.findViewById(R.id.del_yes);
        del_no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.hide();
            }
        });
        del_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               if(ens.isEmpty()){
                   Toast.makeText(getApplicationContext(),"Statistics aleardy empty!", Toast.LENGTH_LONG).show();
                   alertDialog.hide();
               }else{
                   db.DeleteAllData();
                   alertDialog.hide();
                   Toast.makeText(getApplicationContext(),"Statistics deleted successfully", Toast.LENGTH_LONG).show();
               }

            }
        });

        alertDialog.show();
    }

    public boolean sameDate(String d1, String d2){
        if(d1.substring(0,10).equals(d1.substring(0,10))){
            return true;
        }
        return false;
    }

    public ArrayList<String> getAllDateOfEmotion(ArrayList<EltDatabaseStat> ens, String emo){
        ArrayList<String> dates = new ArrayList<>();
        for (int i = 0; i < ens.size(); i++) {
            if (ens.get(i).getEmotion().equals(emo)) {
                dates.add(ens.get(i).getDate());
            }
        }
        return dates;
    }

    public HashMap<String,Float> AllStat(ArrayList<EltDatabaseStat> ens) {
        String[] exps = {"happy","sad","neural","disgust","anger","fear","surprise"};
        HashMap<String, Integer> hashMap1 = new HashMap<>();

        for(int i =0; i<exps.length;i++){
            ArrayList<String> dates = new ArrayList<>();
            dates.addAll(getAllDateOfEmotion(ens, exps[i]));
            hashMap1.put(exps[i],dates.size());
        }
        HashMap<String, Float> mapfin = new HashMap<>();
        Iterator<Map.Entry<String, Integer>> it = hashMap1.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, Integer> pair = (Map.Entry)it.next();
            float v = (float)pair.getValue()/(float)ens.size()*100;
            mapfin.put(pair.getKey(),v);
            it.remove();
        }
        return mapfin;

    }

}
