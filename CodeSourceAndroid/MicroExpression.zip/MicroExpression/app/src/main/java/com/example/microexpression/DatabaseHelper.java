package com.example.microexpression;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.Date;

/**
 * classe de la base de données
 */

public class DatabaseHelper extends SQLiteOpenHelper {
    public static  final String DB_name ="db_moodcheck.db";
    public static  final String TAB_name ="tab_emotions";
    public static  final String col0 = "id";
    public static  final String col1 = "nom";
    public static  final String col2 = "pourcent";
    public static  final String col3 = "date";
    private Context context;

    public DatabaseHelper(@Nullable Context context) {
        super(context, DB_name, null, 1);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table "+TAB_name+" (id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "nom TEXT, " +
                "pourcent TEXT," +
                "date DATETIME DEFAULT CURRENT_TIMESTAMP)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TAB_name);
        onCreate(db);

    }
    public boolean insertData(String emotion, String pourcent){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(col1,emotion);
        contentValues.put(col2, pourcent);
        long res = db.insert(TAB_name, null, contentValues);
        if(res == -1){
            return false;
        }else{
            return true;
        }

    }
    public boolean DeleteAllData(){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM  "+TAB_name);
        return true;
    }
    // statistics
    public  Cursor getAllData() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from "+TAB_name+" ORDER BY date", null);
        return cursor;

    }

}
