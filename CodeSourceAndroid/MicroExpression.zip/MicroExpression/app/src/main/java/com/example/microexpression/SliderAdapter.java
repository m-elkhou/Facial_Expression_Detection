package com.example.microexpression;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.AnimationDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class SliderAdapter extends PagerAdapter {
    Context context;
    LayoutInflater layoutInflater;
    String[] emotions ;
    String[] pourcentages;
    String img_url;

    public SliderAdapter(Context context,String[] emotions,String[] pourcentages, String img_url ){
        this.context = context;
        this.emotions = emotions;
        this.pourcentages = pourcentages;
        this.img_url = img_url;

    }


    @Override
    public int getCount() {
        return emotions.length  ; // 7 emotions = 7 pager
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == (RelativeLayout) object;
    }

    @NonNull
    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        layoutInflater= (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);

        View view = layoutInflater.inflate(R.layout.slide_layout, container, false);

        TextView tv_emotion = (TextView)view.findViewById(R.id.id_emotion);
        TextView tv_per = (TextView)view.findViewById(R.id.id_per_emotion);
        if(emotions[position].equals("happy")){
            tv_emotion.setText("Happiness");
        }
        tv_emotion.setText(emotions[position]);
        tv_per.setText(pourcentages[position]+" %");

        ImageView btn_show_retry = (ImageView) view.findViewById(R.id.btn_show_retry);
        btn_show_retry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, SendImageServer.class);
                context.startActivity(intent);
                // ********* make the finish if exist  verfied good

            }
        });
        //Toast.makeText(context, img_url,Toast.LENGTH_LONG).show();
        CircleImageView img_result = (CircleImageView) view.findViewById(R.id.img_result);
        Glide.with(context).load(img_url).into(img_result);

        //changerCouleurArrierePlan(emotions[position], view);

        LinearLayout lyn_photo = (LinearLayout)view.findViewById(R.id.lyn_photo);
        AnimationDrawable animationDrawable = (AnimationDrawable)lyn_photo.getBackground();
        animationDrawable.setEnterFadeDuration(2000);
        animationDrawable.setExitFadeDuration(4000);
        animationDrawable.start();

        container.addView(view);
        return view;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((RelativeLayout)object);

    }
    public void changerCouleurArrierePlan( String emotion, View view){
        switch(emotion)
        {
            case "Happiness":
                view.setBackgroundColor(Color.GREEN);
                break;
            case "Sadness":
                view.setBackgroundColor(Color.RED);
                break;
            case "Fear":
                ;
                break;
            case "Neural":
                ;
                break;
            case "Surprise":
                ;
                break;
            case "Anger":
                ;
                break;
            default:
                ;
        }
    }
}
