package com.example.microexpression;

import android.content.Context;
import android.content.SharedPreferences;

/*
* Classe permet d'enregister l'adresse ip et le numéro de port de serveur dans le Sharedpreference
 */

public class Pref {


    public static void setPrefs(String keyPort, String valuePort, String keyIP, String valueIP, Context context){

        SharedPreferences sharedpreferences = context.getSharedPreferences("moodCheckSP", Context.MODE_PRIVATE);

        SharedPreferences.Editor editor = sharedpreferences.edit();

        editor.putString(keyPort, valuePort);
        editor.putString(keyIP, valueIP);

        editor.apply();
    }

    public static String getPrefs(String key, Context context){

        SharedPreferences sharedpreferences = context.getSharedPreferences("moodCheckSP", Context.MODE_PRIVATE);

        return sharedpreferences.getString(key, "notfound");
    }
}
