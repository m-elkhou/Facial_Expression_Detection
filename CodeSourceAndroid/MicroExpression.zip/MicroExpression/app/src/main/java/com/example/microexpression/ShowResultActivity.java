package com.example.microexpression;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ShareActionProvider;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

public class ShowResultActivity extends AppCompatActivity {
    private ViewPager viewPager;
    private SliderAdapter sliderAdapter;
    private ImageAnalyzed imageAnalyzed;
    private String[] list_emos, list_pour, list_emotions,list_pourcent;
    private DatabaseHelper db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_show_result);
        db = new DatabaseHelper(this);
        viewPager = (ViewPager)findViewById(R.id.id_slidePager);
        // Datas for test
        /*
        ArrayList<String> emotions = new ArrayList<>();
        emotions.add("Happinesss");emotions.add("Disgust");emotions.add("Anger");
        emotions.add("Neural");emotions.add("Fear");emotions.add("Sadness");
        emotions.add("Surprise");

        ArrayList<String> pourcentages = new ArrayList<>();
        pourcentages.add("34 %");pourcentages.add("50 %");pourcentages.add("70 %");
        pourcentages.add("12 %");pourcentages.add("78 %");pourcentages.add("87 %");
        pourcentages.add("11 %");
        */
        // Real Work
        imageAnalyzed = (ImageAnalyzed) getIntent().getSerializableExtra("image_Result");
        list_emos = imageAnalyzed.listeEmotions();
        list_pour = imageAnalyzed.listePourcent();
        // trier les emotions.
        HashMap<String, Integer> hashMap = new HashMap<String, Integer>();

        for(int i = 0; i <list_emos.length; i++){
            try{
                hashMap.put(list_emos[i],Integer.parseInt(list_pour[i]));
            }catch (NumberFormatException e){
                e.printStackTrace();
            }

        }
        // sorted the hashmap
        Object[] a = hashMap.entrySet().toArray();
        Arrays.sort(a, new Comparator<Object>() {
            public int compare(Object o1, Object o2) {
                return ((Map.Entry<String, Integer>) o2).getValue()
                        .compareTo(((Map.Entry<String, Integer>) o1).getValue());
            }
        });
        list_emotions = new String[7];
        list_pourcent = new String[7];
        int i = 0;

        for (Object e : a) {
            list_emotions[i] = ((Map.Entry<String, Integer>) e).getKey();
            list_pourcent[i] = ((Map.Entry<String, Integer>) e).getValue()+"";
            i = i+1;
        }
        // saved in Database with date systeme
        boolean etat = db.insertData(list_emotions[0], list_pourcent[0]);
        if (etat == false){
            Toast.makeText(getApplicationContext(),"Error while Saving Result!", Toast.LENGTH_LONG).show();
        }

        //pour test
        //list_emotions = new String[]{"Happiness", "Fear", "Disgust", "Sadness", "Surprise", "Neural", "Anger"};
        //list_pourcent = new String[]{"60", "50", "40", "20", "15", "0", "8"};


        //String img_url = "http://via.placeholder.com/300.png";
        String img_url = imageAnalyzed.getUrl();

        sliderAdapter = new SliderAdapter(ShowResultActivity.this,list_emotions,list_pourcent,img_url);

        //sliderAdapter = new SliderAdapter(ShowResultActivity.this,emotions,pourcentages, img_url);
        viewPager.setAdapter(sliderAdapter);





    }
}
