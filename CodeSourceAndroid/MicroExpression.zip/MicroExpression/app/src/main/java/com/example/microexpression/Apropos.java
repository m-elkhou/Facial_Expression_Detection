package com.example.microexpression;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class Apropos extends AppCompatActivity {
    private ImageView btn_apropos_back;
    private LinearLayout layout_anim;
    private AnimationDrawable animationDrawable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_apropos);

        btn_apropos_back = (ImageView)findViewById(R.id.btn_apropos_back);

        // retourner à l'activité principale
        btn_apropos_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Apropos.this, MainActivity.class);
                startActivity(i);
                finish();
            }
        });

        // Animation
        layout_anim = (LinearLayout) findViewById(R.id.layout_anim1);
        animationDrawable = (AnimationDrawable)layout_anim.getBackground();
        animationDrawable.setEnterFadeDuration(2000);
        animationDrawable.setExitFadeDuration(4000);
        animationDrawable.start();
    }
}
