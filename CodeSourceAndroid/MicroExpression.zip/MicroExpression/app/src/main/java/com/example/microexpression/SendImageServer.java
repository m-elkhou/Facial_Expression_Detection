package com.example.microexpression;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
/*
import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;

 */
import com.bumptech.glide.Glide;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Call;
import okhttp3.Callback;

public class SendImageServer extends AppCompatActivity {
    private CircleImageView img_photo;
    private Button btn_envoyer;
    private ImageView btn_send_back, btn_send_cam , btn_send_gallery,btn_send_retry;
    private  AnimationDrawable animationDrawable;
    private LinearLayout lyn_photo, lyn_background, lyn_send, lyn_choose, lyn_wait,  lyn_retry_back;
    public static final int CAMERA_REQUEST = 1000, GALLERY_REQUEST = 2987;
    private Bitmap bitmap = null;
    private byte[] content;
    private String sp_port, sp_ip;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_send_image_server);

        sp_port = Pref.getPrefs("port", getApplicationContext());
        sp_ip = Pref.getPrefs("IP", getApplicationContext());

        img_photo = (CircleImageView)findViewById(R.id.img_photo);
        btn_envoyer = (Button) findViewById(R.id.btn_envoyer);
        btn_send_back = (ImageView)findViewById(R.id.btn_send_back);
        btn_send_cam = (ImageView)findViewById(R.id.btn_send_cam);
        btn_send_gallery = (ImageView)findViewById(R.id.btn_send_gallery);
        lyn_background = (LinearLayout)findViewById(R.id.lyn_background);
        btn_send_retry = (ImageView)findViewById(R.id.btn_send_retry);

        lyn_send = (LinearLayout)findViewById(R.id.lyn_send);
        lyn_send.setVisibility(View.GONE); //* GONE

        lyn_choose = (LinearLayout)findViewById(R.id.lyn_choose);
        lyn_choose.setVisibility(View.VISIBLE); //* VISIBLE

        // pour le progress Bar
        lyn_wait = (LinearLayout)findViewById(R.id.lyn_wait);
        lyn_wait.setVisibility(View.GONE);

        lyn_retry_back = (LinearLayout)findViewById(R.id.lyn_retry_back);
        lyn_retry_back.setVisibility(View.VISIBLE);




        //test


        //byte[] byteArray = getIntent().getByteArrayExtra("image");
        //Bitmap bmp = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
        //Bitmap bmp = BitmapHelper.getInstance().getBitmap();
        //img_photo.setImageBitmap(bmp);

        //******************************************************************************************
        // Animation
        lyn_photo = (LinearLayout) findViewById(R.id.lyn_photo);
        animationDrawable = (AnimationDrawable)lyn_photo.getBackground();
        animationDrawable.setEnterFadeDuration(2000);
        animationDrawable.setExitFadeDuration(4000);
        animationDrawable.start();
        //******************************************************************************************
        btn_envoyer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //calling the method uploadBitmap to upload image
                 //uploadBitmap(content);
                //------------ autre methode
                // check shared prefs
                if(sp_ip!=null && sp_port!=null){
                    String ip = Pref.getPrefs("IP", getApplicationContext());
                    String port =Pref.getPrefs("port", getApplicationContext()) ;
                    String url = "http:/"+ip+":"+port+"/api/image";
                    connectServer(url);
                }
                // pour test
                /*
                String url = "https://moodle.fhgr.ch/pluginfile.php/124614/mod_page/content/4/example.jpg";
                String emos = "Happiness,Sadness,Fear,Neural,Surprise,Anger,Disgust";
                String per = "80,3,10,56,8,0,0";
                ImageAnalyzed imageAnalyzed = new ImageAnalyzed(url,emos,per);
                Intent intent = new Intent(getApplicationContext(), ShowResultActivity.class);

                Bundle b = new Bundle();
                b.putSerializable("image_Result",imageAnalyzed);
                intent.putExtras(b);

                startActivity(intent);

                 */
            }
        });
        //******************************************************************************************
        btn_send_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
        //******************************************************************************************
        // take from camera
        btn_send_cam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent, CAMERA_REQUEST);
            }
        });
        //******************************************************************************************
        // get from gallery
        btn_send_gallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(i, GALLERY_REQUEST);
            }
        });
        //******************************************************************************************
        btn_send_retry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lyn_send.setVisibility(View.GONE);
                lyn_choose.setVisibility(View.VISIBLE);



            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == CAMERA_REQUEST && resultCode == RESULT_OK && null != data){
            bitmap=(Bitmap) data.getExtras().get("data");
            content = getFileDataFromDrawable();
            //Glide.with(this).load(bitmap).into(img_photo);
            img_photo.setImageBitmap(bitmap);
            //BitmapDrawable background = new BitmapDrawable(bitmap);
            //BitmapDrawable background1 = new BitmapDrawable(getResources(), bitmap);
            //lyn_background.setBackgroundDrawable(background1);

            /*final int sdk = android.os.Build.VERSION.SDK_INT;
            if(sdk < android.os.Build.VERSION_CODES.JELLY_BEAN) {
                lyn_background.setBackgroundDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.bg1) );
            } else {
                lyn_background.setBackground(ContextCompat.getDrawable(getApplicationContext(), R.drawable.bg1));
            }*/

            lyn_choose.setVisibility(View.GONE);
            lyn_send.setVisibility(View.VISIBLE);


        }else if(requestCode == GALLERY_REQUEST && resultCode == RESULT_OK && null != data){
            Uri selectedImage = data.getData();
            String[] filePathColumn = { MediaStore.Images.Media.DATA };

            Cursor cursor = getContentResolver().query(selectedImage,filePathColumn, null, null, null);
            cursor.moveToFirst();

            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);
            cursor.close();

            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bitmap = BitmapFactory.decodeFile(picturePath,bmOptions);
            content = getFileDataFromDrawable();


            /*
            ByteArrayOutputStream blob = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 0 , blob);
            byte[] bitmapdata = blob.toByteArray();
            bitmap = BitmapFactory.decodeByteArray(bitmapdata, 0, bitmapdata.length);
            img_photo.setImageBitmap(bitmap);
            */



            Glide.with(this).load(picturePath).into(img_photo);

            //uploadBitmap(bitmap);

            //Glide.with(this).load("https://moodle.fhgr.ch/pluginfile.php/124614/mod_page/content/4/example.jpg").into(img_photo);

            //img_photo.setImageBitmap(bitmap);
            //BitmapDrawable background1 = new BitmapDrawable(getResources(), bitmap);
            //lyn_background.setBackgroundDrawable(background1);
            /*final int sdk = android.os.Build.VERSION.SDK_INT;
            if(sdk < android.os.Build.VERSION_CODES.JELLY_BEAN) {
                lyn_background.setBackgroundDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.bg1) );
            } else {
                lyn_background.setBackground(ContextCompat.getDrawable(getApplicationContext(), R.drawable.bg1));
            }*/

            lyn_choose.setVisibility(View.GONE);
            lyn_send.setVisibility(View.VISIBLE);
        }
    }

    public byte[] getFileDataFromDrawable() {
        /*
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 0, byteArrayOutputStream);
        return byteArrayOutputStream.toByteArray();*/
        ByteArrayOutputStream blob = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100 /* Ignored for PNGs */, blob);
        byte[] bitmapdata = blob.toByteArray();
        return bitmapdata;
    }

    //******************************************* Avec Volley ****************************************************************************
    /*
    private void uploadBitmap(final byte[] content) {
        //getting the tag from the edittext
        final String tags ="user_img";

        //our custom volley request
        VolleyMultipartRequest volleyMultipartRequest = new VolleyMultipartRequest(Request.Method.POST,  UploadServer.UPLOAD_URL,
                new Response.Listener<NetworkResponse>() {
                    @Override
                    public void onResponse(NetworkResponse response) {
                        try {
                            JSONObject obj = new JSONObject(new String(response.data));
                            Toast.makeText(getApplicationContext(), obj.getString("message"), Toast.LENGTH_SHORT).show();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }) {

            /*
             * si il y a autre params avec image
             * on les ajoute ici
             * */
            /*@Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("tags", tags);
                return params;
            }*/


            /*@Override
            public Map<String, String> getHeaders() {
                HashMap<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "image/png");
                return headers;
            }*/

            /*
            @Override
            protected Map<String, DataPart> getByteData() {
                Map<String, DataPart> params = new HashMap<>();
                long imagename = System.currentTimeMillis();
                params.put("image", new DataPart(imagename+".png", content));
                //getFileDataFromDrawable(bitmap)
                return params;
            }
        };

        //ajout de requete au volley
        Volley.newRequestQueue(this).add(volleyMultipartRequest);
    }
    */
    //**************************************** autre methode *********************************************/

    public void connectServer(String url_server){
        long imagename = System.currentTimeMillis();
        //String postUrl= UploadServer.UPLOAD_URL;
        String postUrl = url_server;
        RequestBody postBodyImage = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("image", imagename+".png", RequestBody.create(MediaType.parse("image/*png"), content))
                .build();
        //progress bar
        lyn_wait.setVisibility(View.VISIBLE);

        lyn_retry_back.setVisibility(View.INVISIBLE);
        lyn_send.setVisibility(View.GONE);

        //Toast.makeText(getApplicationContext(),"Please wait ...", Toast.LENGTH_LONG).show();

        postRequest(postUrl, postBodyImage);
    }

    public void postRequest(String postUrl, RequestBody postBody) {

        OkHttpClient client = new OkHttpClient();

        Request req = new Request.Builder().url(postUrl).post(postBody).build();

        client.newCall(req).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                // Cancel the post on failure.
                call.cancel();

                // In order to access the TextView inside the UI thread, the code is executed inside runOnUiThread()
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        lyn_retry_back.setVisibility(View.VISIBLE);
                        lyn_wait.setVisibility(View.GONE);
                        lyn_send.setVisibility(View.VISIBLE);
                        Toast.makeText(getApplicationContext(),"Failed to Connect to Server !\n IP:"+
                                Pref.getPrefs("IP",getApplicationContext())+"\nPort: "+
                                        Pref.getPrefs("port",getApplicationContext()),Toast.LENGTH_LONG).show();
                    }
                });
            }

            @Override
            public void onResponse(Call call, final okhttp3.Response response) throws IOException {
                // In order to access the TextView inside the UI thread, the code is executed inside runOnUiThread()
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        ImageAnalyzed imageAnalyzed  = new ImageAnalyzed();
                        try {
                            //Toast.makeText(getApplicationContext(),response.body().string(),Toast.LENGTH_LONG).show();
                            // affichage the new image

                            // Json object
                            //{"Result":[ {"url":"url_img", "emotions":"(ha, anger,...)","pourcent":"(40, 70, ...)"} ]}

                            String jsonData = response.body().string();
                            JSONObject Jobject = new JSONObject(jsonData);
                            String url = Jobject.getString("url");
                            String status = Jobject.getString("status");
                            //Toast.makeText(getApplicationContext(),url,Toast.LENGTH_LONG).show();
                            String emotions = Jobject.getString("emotions");
                            String pourcent = Jobject.getString("pourcentages");

                            imageAnalyzed.setUrl(url);
                            imageAnalyzed.setEmotions(emotions);
                            imageAnalyzed.setPourcent(pourcent);

                            // set the imageAnalyzed attribut and send it using bundle in the intent
                            if (status.equals("200")==true) {
                                Intent intent = new Intent(getApplicationContext(), ShowResultActivity.class);

                                Bundle b = new Bundle();
                                b.putSerializable("image_Result",imageAnalyzed);
                                intent.putExtras(b);

                                startActivity(intent);
                                finish();
                            }else{
                                Intent intent = new Intent(getApplicationContext(), InvalidImageActivity.class);
                                startActivity(intent);
                                finish();

                            }




                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        //lyn_wait.setVisibility(View.GONE);
                        //lyn_retry_back.setVisibility(View.VISIBLE);

                    }
                });
            }
        });
    }







//******

}
