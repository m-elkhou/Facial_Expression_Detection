package com.example.microexpression;

/**
 * les données qu'on recupère depuis le database
 */
public class EltDatabaseStat {
    private String emotion;
    private String date;

    public EltDatabaseStat(String emotion, String date) {
        this.emotion = emotion;
        this.date = date;
    }

    public String getEmotion() {
        return emotion;
    }

    public void setEmotion(String emotion) {
        this.emotion = emotion;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
